package controller;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import entities.Actualities;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import entities.Events;
import services.ActuService;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.net.URL;
import static java.sql.DriverManager.println;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.stage.FileChooser;
import services.EventService;

/**
 *
 * @author Administrator
 */
public class GestionController implements Initializable {

    @FXML
    private Label label;
    @FXML
    private TextField name;
    @FXML
    private TextField memberid;
    @FXML
    private DatePicker date;
    @FXML
    private TextField description;

    @FXML
    private Button browse;
    @FXML
    private TableView<Events> tableau;
    String pathimage1=null;
    String pathimage=null;
    @FXML
    private TableColumn<Events, String> namecol;
    @FXML
    private TableColumn<Events, Integer> memidcol;
    @FXML
    private TableColumn<Events, String> piccol;
    @FXML
    private TableColumn<Events, String> datecol;
    @FXML
    private TextField pickUpPathField;
    
    //public ListData listdata;
    @FXML
    private TableColumn<Events, String> desccol;
    @FXML
    private Tab events;
    @FXML
    private AnchorPane menu;
    @FXML
    private Tab actualities;
    @FXML
    private TextField memberid_Act;
    @FXML
    private TextField description_Act;
    @FXML
    private Button browse1;
    @FXML
    private TextField pickUpPathField1;
    @FXML
    private Button add_Act;
    @FXML
    private Button update_Act;
    @FXML
    private Button delete_Act;
    @FXML
    private TextField title;
    @FXML
    private TableColumn<Actualities, String> titlecol;
    @FXML
    private TableColumn<Actualities, Integer> memidcolA;
    @FXML
    private TableColumn<Actualities, String> photocolA;
    @FXML
    private TableColumn<Actualities, String> datecolA;
    @FXML
    private TableColumn<Actualities, String> desccolA;
    @FXML
    private TableView<Actualities> tableauAct;

    public GestionController()   throws SQLException    {
     //   this.listdata = new ListData();
        
    }
    EventService se = new EventService();
    ActuService see = new ActuService();

    
    public void initialize(URL url, ResourceBundle rb) {
            
        
        try {
            // TODO
            
            ObservableList<Events> list= se.getEventsList();
            ObservableList<Actualities> listA= see.getActuList();

            namecol.setCellValueFactory(new PropertyValueFactory<>("name_eve"));
            memidcol.setCellValueFactory(new PropertyValueFactory<>("id_member"));
            piccol.setCellValueFactory(new PropertyValueFactory<>("photo_eve"));
            datecol.setCellValueFactory(new PropertyValueFactory<>("date_eve"));
            desccol.setCellValueFactory(new PropertyValueFactory<>("description_eve"));
            
            //tableau.setItems(list);
            println("affichege winou?");
            titlecol.setCellValueFactory(new PropertyValueFactory<>("title_act"));
            memidcolA.setCellValueFactory(new PropertyValueFactory<>("id_member"));
            photocolA.setCellValueFactory(new PropertyValueFactory<>("photo_act"));
            datecolA.setCellValueFactory(new PropertyValueFactory<>("date_act"));
            desccolA.setCellValueFactory(new PropertyValueFactory<>("description_act"));
            tableauAct.setItems(listA);
            tableau.setItems(list);
        } catch (SQLException ex) {
            Logger.getLogger(GestionController.class.getName()).log(Level.SEVERE, null, ex);
        }

            
       
   
        

    }

    @FXML
    private void add(ActionEvent event) throws SQLException {
        String memid = memberid.getText();
        int idd = Integer.parseInt(memid);
        String datee = date.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

        //Events e = new Events("aa", "pop", "aa", "pop",8 );
        Events e =  new Events(name.getText(), datee, description.getText(), pickUpPathField.getText(), idd);
        EventService es = new EventService();
        //System.out.println(e);
        try {
            es.insert(e);
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Done");
            alert.setContentText("Addeded!");
            alert.show();
        } catch (Exception ee) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error!");
            alert.show();
        }
    }

    @FXML
    private void update(ActionEvent event) {
        
            String datee = date.getValue().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));

         try {
              Events a = tableau.getSelectionModel().getSelectedItem();
        if (a!=null){
            EventService sa = new EventService();
            //a.setCategorie_id(categorieA.getSelectionModel().getSelectedItem().getId());
           // a.setNom(nomText.getText());
            a.setDescription_eve(description.getText());
            a.setDate_eve(datee);
            a.setPhoto_eve(pathimage);
            se.updateEve(a.getName_eve(),a.getDate_eve(), a.getDescription_eve(), a.getPhoto_eve(),a.getId_member());
            tableau.refresh();
         
        }
        
            
             println("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
             ObservableList<Events> list= se.getEventsList();
            namecol.setCellValueFactory(new PropertyValueFactory<Events,String>("name_eve"));
            memidcol.setCellValueFactory(new PropertyValueFactory<Events,Integer>("id_member"));
            piccol.setCellValueFactory(new PropertyValueFactory<Events,String>("photo_eve"));
            datecol.setCellValueFactory(new PropertyValueFactory<Events,String>("date_eve"));
            desccol.setCellValueFactory(new PropertyValueFactory<Events,String>("description_eve"));
            
             tableau.setItems(list);
        } catch (SQLException ex) {
               ex.getCause().printStackTrace();
            Logger.getLogger(GestionController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }


    @FXML
    private void delete(ActionEvent event) {
        
       
        try {
             EventService su= new EventService();
            Events u= new Events();
            String namee = name.getText();
            u.setName_eve(namee);
            System.out.println(namee);
            su.DelEve(u);
           
            //System.out.printlnid);
          //  su.DelEve(u);
            ObservableList<Events> list= su.getEventsList();
            namecol.setCellValueFactory(new PropertyValueFactory<Events,String>("name_eve"));
            memidcol.setCellValueFactory(new PropertyValueFactory<Events,Integer>("id_member"));
            piccol.setCellValueFactory(new PropertyValueFactory<Events,String>("photo_eve"));
            datecol.setCellValueFactory(new PropertyValueFactory<Events,String>("date_eve"));
            desccol.setCellValueFactory(new PropertyValueFactory<Events,String>("description_eve"));
            
            tableau.setItems(list);
        } catch (SQLException ex) {
           // println(ex.getCause());
            ex.getCause().printStackTrace();
            Logger.getLogger(GestionController.class.getName()).log(Level.SEVERE, null, ex);
        }
    
            
    }
   
    private String browsemouse(MouseEvent event) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG Files", "*.png"));
        List<File> f = fc.showOpenMultipleDialog(null);

        for (File file : f) {
            //System.out.println(f);

        }
        return f.toString();

    }

    @FXML
    private void browse(ActionEvent event) throws FileNotFoundException {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("image", "*.png"));
        List<File> f = fc.showOpenMultipleDialog(null);
        String x = "/";
        for (File file : f) {
            x = file.getAbsolutePath();
            pickUpPathField.setText(file.getPath());

        }
        Image image = new Image(new FileInputStream(f.get(0)));

        pathimage = x;

    }

    @FXML
    private void browseAct(ActionEvent event) throws FileNotFoundException {
          FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("image", "*.png"));
        List<File> f = fc.showOpenMultipleDialog(null);
        String x = "/";
        for (File file : f) {
            x = file.getAbsolutePath();
            pickUpPathField1.setText(file.getPath());

        }
        Image image = new Image(new FileInputStream(f.get(0)));

        pathimage1 = x;
    }

    @FXML
    private void addAct(ActionEvent event) throws SQLException {
        String memid = memberid_Act.getText();
        int idd = Integer.parseInt(memid);
        String datee = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        ObservableList<Actualities> listA= see.getActuList();

        //Events e = new Events("aa", "pop", "aa", "pop",8 );
        Actualities e =  new Actualities(title.getText(), datee, description_Act.getText(), pickUpPathField1.getText(), idd);
        ActuService es = new ActuService();
        //System.out.println(e);
        es.insertAct(e);
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("success");
        alert.show();
        println("affichege winou?");
        titlecol.setCellValueFactory(new PropertyValueFactory<>("title_act"));
        memidcolA.setCellValueFactory(new PropertyValueFactory<>("id_member"));
        photocolA.setCellValueFactory(new PropertyValueFactory<>("photo_act"));
        datecolA.setCellValueFactory(new PropertyValueFactory<>("date_act"));
        desccolA.setCellValueFactory(new PropertyValueFactory<>("description_act"));
        //  ObservableList<Actualities> listA= see.getActuList();
        tableauAct.setItems(listA);
    }
   

    @FXML
    private void updateAct(ActionEvent event) {
    }

    @FXML
    private void deleteAct(ActionEvent event) {
        
        ActuService su = new ActuService();// println(ex.getCause());
        Actualities u= new Actualities();
        String titlee = title.getText();
        u.setTitle_Act(titlee);
        System.out.println(titlee);
        su.DelAct(u);
        
        //System.out.printlnid);
        //  su.DelEve(u);
    }

    @FXML
    private String browseAct(MouseEvent event) {
        FileChooser fc = new FileChooser();
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("PNG Files", "*.png"));
        List<File> f = fc.showOpenMultipleDialog(null);

        for (Iterator<File> it = f.iterator(); it.hasNext();) {
            File file = it.next();
        } //System.out.println(f);
        return f.toString();
    }

    @FXML
    private void updateview(Event event) throws SQLException {
        
        
        
            ObservableList<Actualities> listA= see.getActuList();
            titlecol.setCellValueFactory(new PropertyValueFactory<>("title_act"));
            memidcolA.setCellValueFactory(new PropertyValueFactory<>("id_member"));
            photocolA.setCellValueFactory(new PropertyValueFactory<>("photo_act"));
            datecolA.setCellValueFactory(new PropertyValueFactory<>("date_act"));
            desccolA.setCellValueFactory(new PropertyValueFactory<>("description_act"));
            tableauAct.setItems(listA);
       
    }
    
    
    
   

}