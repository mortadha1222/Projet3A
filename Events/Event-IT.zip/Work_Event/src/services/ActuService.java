/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package services;

/**
 *
 * @author Bali 
 * 
 */
import entities.Actualities;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import controller.GestionController;
import static java.sql.DriverManager.println;
import java.sql.PreparedStatement;
import utils.MyDB;
public class ActuService {
    Connection cnx;
    Statement ste;
    ResultSet rs;
      public ActuService() {
        try {
            cnx = MyDB.getInstance().getCnx();
            ste = (Statement) cnx.createStatement();
        } catch (SQLException ex) {
            Logger.getLogger(ActuService.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
         public void insertAct(Actualities u) {
        String req = "insert Actualities  (title_act,date_act,description_act,photo_act,id_member) values ('" + u.getName_Act() + "','" + u.getDate_Act() + "','" + u.getDescription_Act() + "','" + u.getPhoto_Act() + "','" + u.getId_Member() + "')";
        try {
            ste.executeUpdate(req);
        } catch (SQLException ex) {
            Logger.getLogger(EventService.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
    }
           public ObservableList<Actualities> getActuList() throws SQLException {
        ObservableList<Actualities> ActuList = FXCollections.observableArrayList();
        Statement stm = cnx.createStatement();
        String query = "select  title_act, date_act, description_act , photo_act , id_member from actualities";
        //ResultSet rs;
        rs = stm.executeQuery(query);
        Actualities Act;
        while (rs.next()) {
            Act = new Actualities(rs.getString("title_act"), rs.getString("date_act"), rs.getString("description_act"), rs.getString("photo_act"), rs.getInt("id_member"));
           // System.out.println(Act.getPhoto_Act());
            ActuList.add(Act);

        }
        return ActuList;

    }
 public void DelAct(Actualities u) {
       try {
            Statement stm=cnx.createStatement();
            String query="delete  from actualities where title_act = '"+u.getName_Act()+"'";
            println(query);
            stm.executeUpdate(query);
            
       } catch (SQLException ex) {
           Logger.getLogger(ActuService.class.getName()).log(Level.SEVERE, null, ex);
       }
    }
}
