/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

/**
 *
 * @author Administrator
 */
public class Actualities {
    private int id_Act;
    private String title_Act;

    public void setId_Act(int id_Act) {
        this.id_Act = id_Act;
    }

    public void setTitle_Act(String title_Act) {
        this.title_Act = title_Act;
    }

    public void setDate_Act(String date_Act) {
        this.date_Act = date_Act;
    }

    public void setDescription_Act(String description_Act) {
        this.description_Act = description_Act;
    }

    public void setPhoto_Act(String photo_Act) {
        this.photo_Act = photo_Act;
    }

    public void setId_Member(int id_Member) {
        this.id_Member = id_Member;
    }
    private String date_Act;
    private String description_Act;
    private String photo_Act;
    private int id_Member ;

    public Actualities(String name_Act, String date_Act, String description_Act, String photo_Act, int id_Member) {
        this.title_Act = name_Act;
        this.date_Act = date_Act;
        this.description_Act = description_Act;
        this.photo_Act = photo_Act;
        this.id_Member = id_Member;
    }

    public Actualities() {
    }

    @Override
    public String toString() {
        return "Actualities{" + "name_Act=" + title_Act + ", date_Act=" + date_Act + ", description_Act=" + description_Act + ", photo_Act=" + photo_Act + ", id_Member=" + id_Member + '}';
    }

    public int getId_Act() {
        return id_Act;
    }

    public String getName_Act() {
        return title_Act;
    }

    public String getDate_Act() {
        return date_Act;
    }

    public String getDescription_Act() {
        return description_Act;
    }

    public String getPhoto_Act() {
        return photo_Act;
    }

    public int getId_Member() {
        return id_Member;
    }
    
    
}
